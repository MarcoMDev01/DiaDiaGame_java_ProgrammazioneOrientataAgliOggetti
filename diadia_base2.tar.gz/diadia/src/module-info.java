/**
 * 
 */
/**
 * @author User
 *
 */
module diadia {
	requires org.junit.jupiter.api;
	requires junit;
}