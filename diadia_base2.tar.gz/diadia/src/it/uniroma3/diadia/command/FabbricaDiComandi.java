package it.uniroma3.diadia.command;

public interface FabbricaDiComandi {
public Comando costruisciComando(String istruzione);
}